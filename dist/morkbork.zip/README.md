# MorkBork
A Mörk Borg game system for foundry vtt

This is forked from @trickyturtle https://github.com/trickyturtle/morkborkFVTT

We're pretty much using this as a learning platform and any changes should be handled with a mild scepticism and huge caution, much like Mörk Borg itself actually. Darkness is ahead. 


### DISCLAIMER
MorkBork is an independent production and is not affiliated with Ockult Örtmästare Games or Stockholm Kartell. It is published under the MÖRK BORG Third Party License.

MÖRK BORG is copyright Ockult Örtmästare Games and Stockholm Kartell. 
