# morkborkFVTT
A Mork Borg game system for foundry vtt

This is forked from @trickyturtle https://github.com/trickyturtle/morkborkFVTT

We're pretty much using this as a learning platform and any changes should be handled with a mild scepticism and huge caution, much like Mörk Borg itself actually. Darkness is ahead. 